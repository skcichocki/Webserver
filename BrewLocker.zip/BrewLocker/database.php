<?php
    $dsn = 'mysql:host=localhost;dbname=brew_locker';
    $username = 'root';
    $password = 'goodwill';

    try {
        $db = new PDO($dsn, $username, $password);
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        include('database_error.php');
        exit();
    }
?>