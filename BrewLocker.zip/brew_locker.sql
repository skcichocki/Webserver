-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2017 at 01:17 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `brew_locker`
--
CREATE DATABASE IF NOT EXISTS `brew_locker` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `brew_locker`;

-- --------------------------------------------------------

--
-- Table structure for table `beers`
--

CREATE TABLE `beers` (
  `beer_ID` int(11) NOT NULL,
  `brewery_ID` int(11) NOT NULL,
  `beer_name` varchar(50) NOT NULL,
  `abv` decimal(3,1) NOT NULL,
  `beer_description` varchar(1000) CHARACTER SET utf8 COLLATE utf8_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `beers`
--

INSERT INTO `beers` (`beer_ID`, `brewery_ID`, `beer_name`, `abv`, `beer_description`) VALUES
(1, 100234, 'Jalapeno Pale Ale', '5.5', 'The Jalapeno Pale is in a class by itself. Using our Free Will Pale as a foundation, we add a generous amount of fresh, hand-cut jalapenos mixed with a hint of awesome. Don\'t be scared to try it! The Jalapeno is refreshing, crisp, and pairs well with the peanuts we have in the tap room!'),
(2, 100234, 'Lazy Bird Brown Ale', '5.5', 'A smooth, roasty ale with rich cocoa aromatics, our Brown Ale has the cojones to stand up to cool weather, but with a firm bitterness and spicy, floral hop flavor it doesn\'t come across too heavy.'),
(3, 100234, 'Free Will Pale Ale', '5.5', 'Free Will Pale is a Pale Ale designed to be sessionable and approachable for drinkers from any beer background. The beer combines traditional English hop varieties (Fuggles) as well as new American varieties (Galena) to create a floral and slightly citrusy hop aroma with a decent bitterness behind it. The malt background is just as delicate with hints of toast and honey flavors.'),
(4, 100234, 'Higher Ground IPA', '7.0', 'Higher Ground, our first high gravity offering, is a classic West Coast IPA style, with a hearty dose of Cascade hops to create a delicious citrusy flavor and aroma. We also include specialty crystal malts to give the beer it\'s unique caramel color and firm malt foundation. It\'s noticeable bitterness is balanced by a subtle caramel background to make for an easy drinking IPA. '),
(5, 254896, 'The Five Pillars', '5.0', 'We brew unique interpretations of classic American, English, and German beers, using pesticide-free, locally-sourced ingredients, whenever available.\r\n\r\nWe offer five flagship beers and a unique rotating selection of specialty and seasonal beers. Stop by our taproom and you will even find several options from some of our other favorite Charlotte craft breweries.'),
(6, 254896, 'Amber Blaze Amber', '5.6', 'This is our take on the classic American Amber. Amber Blaze will remind you of the first craft beer you ever fell in love with. Turned up to 11. We push the classic style with a biscuit-forward maltiness and generous hop flavor and aroma.'),
(7, 254896, 'Double Blaze Black IPA', '6.1', 'We love brewing complex beers that blend two classic styles, transcending both to form something unique and delicious. In this case, we\'ve introduced Porter and IPA, resulting in a beautiful balance of citrus hop flavors and tropical aromas, packed tightly into a medium‐body dark ale with a roasty finish.'),
(8, 254896, 'Black Blaze Milk Stout', '5.0', 'Our milk stout is a classic English mainstay. Black Blaze is a medium-bodied, creamy, dark beer. It has a slightly sweetened roastiness with hints of espresso & chocolate. This is a dark beer that you can drink all day long. In fact, I\'m drinking one right now.'),
(9, 100000, 'La Leche Papi, La Leche', '5.2', 'Pale Ale w/ Milk Sugar'),
(10, 100000, 'Uncle Bob\'s Sweet Nuts', '6.3', 'Maple Pecan Porter'),
(11, 100000, 'The Fizzle', '4.2', 'Carolina Common on Nitro'),
(12, 100000, 'Rootin\' Tootin\'', '6.2', 'Sweet Tater Gruit w/ Ginger, Turmeric & Juniper'),
(13, 784044, 'Riverbent & Hell Bound', '4.5', 'A very light easy drinking Belgian single ale brewed with local malt from Riverbend Malt House.'),
(14, 784044, 'Cellar Door', '5.4', 'This dry hopped session Saison has a little something for everyone. It had a light mouthful and easy start for the patio beer sipper, and it has a nice citrus hop aroma and finish for the hardcore hop head.'),
(15, 784044, 'Tu Bock Shakur', '7.8', 'Bock strength German wheat beer. Undergoes a decoction mash with a hefeweizen yeast, it has a malty/caramelized banana clove characteristic with a slightly sweet finish.'),
(16, 784044, 'IMP', '11.8', 'Brewed with our proprietary coffee blend from Magnolia Coffee with Vermont maple syrup.'),
(17, 226560, 'Carolina Sparkle Party', '4.0', 'We use a traditional Kettle Sour brewing method and a hint of Brettanomyces to add depth and tartness to this light, German Wheat Beer. A party in your mouth!!!'),
(18, 226560, 'Hay Diddle Diddle', '4.3', 'Originally brewed for Belgian miners... Saison yeast, a large portion of wheat, and a good ole bale of hay create a complex, yet approachable and refreshing beer.'),
(19, 226560, 'Project Pils', '4.8', 'Brewed exclusively with locally grown Pilsner malt produced by our friends in Asheville, NC at Riverbend Malt. Sterling hops add herbal characteristics and moderate bitterness that complement the grainy sweetness and a crisp, dry finish. To be consumed with friends in mass quantities.'),
(20, 226560, 'Dos Amigos', '5.0', 'Unfiltered and Unafraid like \"Two Friends\" should be... this rustic lager was brewed with a traditional decoction-style mash to add a light, toasted malt aroma and flavor with just the right amount of hop bitterness to provide a balanced finish.'),
(21, 351960, 'Par-4', '4.0', 'Stay in the zone with a low ABV beer that still packs robust flavor and mouthfeel. Brewed with nearly four pounds of hops per barrel and mashed with oats, Par 4 has a smooth and balanced body to even out the payload delivered by a bouquet of select West Coast hops.'),
(22, 351960, 'Jam Session', '5.1', 'The evolution of American Pale Ale-still a session beer but it sacrifices nothing-clear hop flavor shines through without being too dominant, and there\'s a great malt flavor uncommon to the variety. The backbone of this beer is the balance of imported Maris Otter and Caramunich malts with the pine and citrus flavors of Simcoe and Citra hops.'),
(23, 351960, 'Woody & WilCox', '5.2', 'Woody and Wilcox Wheat Ale is a straight forward, refreshing ale with full mouth feel and clean finish.  It has a subtle hop character with faint citrus notes and a smooth, clean flavor that is accented by both wheat malt and flaked oats.  \nNamed after our friends Woody & Wilcox, the morning duo on Charlotte\'s 106.5 The End.  Their show\'s a great way to get your morning started!  Call in and tell them we said hello.'),
(24, 351960, 'Hop Drop \'N Roll', '7.2', '2014 World Beer Cup Gold Award Winner, American-Style IPA. Hops in your face. Crisp, mouthwatering, American citrus hops dominate for an ideal IPA character. It\'s hopped before, during and after the boil with late boil additions of Citra and Amarillo for a complex flavor profile. The rich golden color comes from a blend of English and American base malts accented with substantial amounts of Vienna and Wheat malt. This is the beer that started it all for NoDa Brewing.'),
(34, 0, '', '0.0', ''),
(35, 548421, 'Pale Ale', '5.2', 'A multicultural fusion combining American and European styles. This ale, brewed with imported Belgian specialty malts supported by a traditional English floor malt backbone, is hopped with some of America\'s most popular whole-cone hop varieties yielding a surprisingly refreshing and well-balanced pale ale.  Pronounced flavors of fruit, citrus, pine and grapefruit balance a caramelized toastiness from our unique malt combination appealing to both hop-heads and malt-lovers alike.'),
(36, 548421, 'Biere de Garde', '6.8', 'Name literally means, \"Beer which has been kept or lagered.\" No expense was spared in recreating this traditional artisanal ale from Northern France. To recreate this regional specialty, we imported all of the ingredients from the countries that birthed the style. The end result is a malt-forward amber with deep hints of caramel and candied apple. Eight different specialty malts come together to yield a magnificently complex malt profile. '),
(37, 548421, 'Belgian Dubbel', '7.6', 'Complex, mysterious and deceivingly dangerous, our Belgian Dubbel is both easy-drinking and full of character. Inspired by one of our favorite recipes, this craft beer will keep you guessing with an interplay of flavors: plum, raisin, spice, banana, clove, chocolate, brown sugar, and cherry can all be found in a single tasting! '),
(38, 548421, 'Saison', '6.6', 'A traditional farmhouse ale that dates back to the origin of agriculture in Southern Belgium, this style was brewed by farmers to nourish their seasonal workers - known as Saisonniers -  during the grueling work of the season\'s harvest. A fairly strong beer with an ABV of 6.6%, Saison\'s were traditionally brewed in the winter strong enough to preserve them for the following year\'s harvest but light enough to quench the farmhands\' thirst. '),
(39, 357951, 'Good Morning Vietnam', '5.0', 'Made with locally roasted Ethiopian Coffee from our friends at Enderly Coffee Roasters and rich Madagascar Vanilla Beans.  The result is a unique beer that is both approachable and complex.'),
(40, 357951, 'Overachiever', '5.3', 'Overachiever exceeds expectations by packing the citrusy, juicy hop character of our favorite IPA\'s into an obsessively drinkable pale ale.  Brewed with pale and caramel malts, oats, Simcoe and Centennial Hops, and our house ale yeast.'),
(41, 357951, 'What He\'s Having', '6.7', 'Brewed with over 3 pounds of bold, American hops per barrel. This IPA combines citrus and tropical fruit notes with a silky, light body and restrained bitterness.'),
(42, 357951, 'What I\'m Having', '4.8', 'All the juicy hop flavor you crave with less of the intoxicating qualities of it\'s big brother. This batch of What I\'m Having is brewed with local rye malt, and generously hopped with Denali and Azacca.'),
(43, 654987, 'boll Weevil Brown Ale', '5.0', 'A classic English brown ale. Medium bodied and moderate with caramel sweetness. Low hop additions allow the caramel and roasted malts to dominate this old style beer.'),
(44, 654987, 'Cabarrus Cotton Blonde Ale', '4.7', '\r\nAmerican style cream ale. Light bodied and crisp golden and refreshing, this is our lightest beer and is the ale version of an American pilsner using classic noble hops.'),
(45, 654987, 'Mule Spinner Stout', '5.0', 'A full bodied, oatmeal stout. Roasted caramel and chocolate malts are used to give this beer its rich flavor. Oatmeal provides a creamy, sweet body and complexity.'),
(46, 654987, 'Red Hill Amber', '5.0', 'A medium bodied red ale. Malty sweetness and caramel flavors supported by medium hop bitterness round out this balanced ale.'),
(47, 987654, 'Candor Tart Peach Ale', '6.4', 'A barrel-aged beer fermented on peaches. Aged approximately 6 months with a mixed culture fermentation, making the beer slightly tart.'),
(48, 987654, 'Is It Hoppy? Double IPA', '8.2', 'This smooth drinking IPA was dry hopped with the most hops we\'ve ever used. Heavy additions of Vic Secret hops were added, along with smaller additions of Mosaic and Centennial to create intense aromatics and notes of tropical fruits with pine.'),
(49, 987654, 'Pounder (DDH) Hazy Pale Ale', '5.2', 'This Pale Ale has the same base recipe as our regular Pounder, but was dry hopped with twice the amount of Simcoe. Smooth, citrus and haze!'),
(50, 987654, 'Rye\'d Sally Rye\'d Rye Saison', '5.3', 'A Saison brewed with flaked rye for a nice spiciness on the back end. We also added East Kent Golding hops for a nice flavor and aroma.'),
(51, 159753, 'Underground Pale Ale', '5.0', 'A strong hop aroma from American hop varieties like Cascade and El Dorado\n\nwith a wide range of characteristics of big citrus, floral, tropical fruit, and melon notes. Medium maltiness supports the hop presentation. Pale golden in color, like iron pouring from the furnaces of yesteryear. This is a pale, refreshing and hoppy ale, with a sufficient supporting malt backbone to make the beer balanced.'),
(52, 159753, 'Homewood Hefe', '5.0', 'A crisp n\' tasty hometown tradition!\n\nStyled after the classic German Breakfast Ale, Homewood\'s new favorite Hefe perfectly balances a cloudy light feel with low-hop, malty sweetness. Accented with traditional clove, banana, and light vanilla notes, and served unfiltered in a traditional Weizen glass, this sexy-looking beer is bound to put a smile on your face.'),
(53, 484707, 'Imperial IPA', '8.0', 'A sharp crisp almost dry India Pale Ale. This is a massive citrusy '),
(54, 484707, 'Brown Ale', '6.2', 'A brown ale with a nice chocolate and coffee aroma.'),
(55, 484707, 'Amber ', '5.8', 'This is a great smooth sharp crisp amber with a nice hop profile.'),
(56, 484707, 'Black Orange Citrus IPA', '6.8', ' A great hoppy Citrusy dark roast IPA.'),
(57, 484707, 'Double Cheek IPA ', '8.2', 'A dry sharp hopped up double IPA with Galaxy hops. Has a great musadine aroma'),
(58, 484707, 'Orange Citrus IPA', '6.7', 'A strong citrusy smooth IPA with orange peel added to enhance the orange aromas in the hops being added. '),
(59, 484707, 'Lemon Wheat IPA', '6.7', 'A strong search ace hopped IPA with lemon peel added to boil. This is a light and great summer beer. '),
(60, 484707, 'Star Fruit Tart', '5.1', 'A sour brewed with star fruits to add a tropical aroma and taste to this unique sour.'),
(61, 572224, 'Pale Ale', '4.8', 'a nice, smooth, easy drinking pale colored ale that captures a bit of traditional English-style ale while infusing a bit of America into it.  It has a light malt background with a slight hop finish to it providing balance and drinkability.  It is also the beer that is infused with jalapenos for a different, spicy drinking experience.'),
(62, 572224, 'Brown Ale', '5.5', 'a beer with hints of chocolate and caramel.  The Willamette hop gives this almost sweet beer its balance while the East Kent Goldings give it that nice, moderate, bitter finish.  Aromas of biscuit and malt really make this a great complement to most meals, and its modest alcohol content (5.5%) makes it a beer that can be enjoyed without worry.'),
(63, 750667, 'Swell Rider', '5.1', 'A kickflip of an IPA, Swell Rider is made to be enjoyed relentlessly throughout the day. Splashed with tangerines and waves of pineapple, mango and stone fruit hops.'),
(64, 750667, 'Brown Sugar Brown Cow', '6.9', 'This Mocha Brown ale needed a fanatical bovine with a brown sugar sweet side and a kick of Colombian coffee. Brown Sugar Brown Cow is brewed with chocolate, vanilla, brown sugar and Colombian coffee. We added a hint of lactose, and this brew is a mocha coffee and cream concoction so good you\'ll say its name.'),
(65, 750667, 'Hakuna Matata', '6.5', 'Tropical IPA brewed using hops from the US, UK, Germany, Slovenia, and New Zealand. The result is a much more balanced, less bitter but more flavorful Dank-style IPA with hints of Mandarin Orange, Pineapple, Grapefruit, and Elderflower.'),
(66, 890566, 'PRIMAL PALE ALE', '6.0', 'A lightly hopped, amber colored ale ac- cented with tangerine notes from Summit Hops.'),
(67, 890566, 'LEMON HAZE', '6.1', 'A combination of pale ale and wheat beer made with Lemondrop Hops. This beer has a bright lemon flavor and ample hop bitterness.'),
(68, 890566, 'CRAVEN\'S ELIXIR', '6.3', 'A traditional American IPA with promi- nent hop aroma and bitterness. Malt flavor includes hints of caramel and a clean, slight sweetness with a dry finish.'),
(69, 890566, 'POJO IPA', '6.7', 'A light colored, medium bodied American IPA with prominent hop aroma from Centennial Hops added in both the kettle and fermenter.'),
(70, 890566, 'GRIM CREEPER', '9.2', 'A robust, malty Imperial IPA with high IBUs from a 90 minute boil with plentiful hop additions. Smooth and easy drinking but be careful...it creeps up on you in the end!'),
(71, 983883, 'Amstel Light', '4.0', 'Amstel Light is brewed in Amsterdam, part of brewing tradition that dates back to 1870. At just 95 calories per bottle. It\'s unique mixture of barley and hops delivers a full - never diluted - flavor that\'s just as tasty as regular beer.'),
(72, 983883, 'Asheville Brewing Love Ninja Porter', '5.6', 'We add sweet raspberries, vanilla, & chocolate to Ninja Porter for a delicious mouth sensation.Plus lactose to make this a smooth milk porter.'),
(73, 983883, 'Blackberry Smoke “Like An Arrow” Wheat Ale', '5.2', 'Asheville Brewing Company and Southern rock/country band Blackberry Smoke made a beer together. \"Like an Arrow\" blackberry-infused wheat ale is named for Blackberry Smoke\'s new critically acclaimed album, \"Like An Arrow.\"'),
(74, 983883, 'Brewnicorn', '4.8', 'American-style Wheat Ale with raspberries and blueberries. Typically released in Fall and Spring. One of our occasional brewpub exclusives.'),
(75, 900628, 'Wheatseeker Hefeweizen', '4.8', 'Wheatseeker is a German-style Hefeweizen, fermented with a yeast strain used in Germany for hundreds of years.  A light-bodied easy-drinker, with a wheat and yeast combination that creates a slightly spicy character.   We hopped it with German grown Opal hops, which lends a slight citrus effect.'),
(76, 900628, 'ESB', '5.5', 'A malty amber ale boasting rich toasted and caramel flavors, Green Man ESB is one of our award-winning signature brews. Our blend of authentic British malts and hops creates a nutty aroma, full body, and a sweet finish. Prepare yourself for a truly exceptional interpretation of a traditional English style.'),
(77, 900628, 'The Rainmaker', '9.3', 'It\'s no myth that this is Green Man\'s most impressive and sought after special offering. A mammoth Double IPA that boasts 4 different hops, it\'s the one hopheads wait for. Like a cool rain after a long drought, this one will quench your desire for big flavor and balance. Meet the Maker! '),
(78, 900628, 'Funk #49', '6.8', 'Asheville\'s first sour beer! A complex red ale aged for 6 months in one of our \"magic\" barrels, then for another 3 months in a rum barrel.  We look forward to its return, one day! Who\'s got the funk?  We got the funk!'),
(79, 900628, 'The Dweller', '10.0', 'Robust and warming, this stout has hints of coffee and dark chocolate. A complex variety of roasted malts, and moderate hopping temper the pleasant sweetness of this brew. This special batch lurked in our cellar until our brewers felt it was worthy of its name. '),
(80, 900628, 'IPA', '6.2', 'Green Man India Pale Ale is delectably hoppy with a properly balanced body. Generous hop additions give it a wonderful bitterness and pleasant floral nose, while our combination of traditional British malts creates a rich, satisfying flavor and alluring copper color. This authentic English-style IPA is our flagship ale.'),
(81, 340281, 'HI-WIRE', '4.6', 'This true American lager is as approachable as it is delicious, a perfect balance of light Pilsen malt and German hops. Extensively lagered until the beer reaches peak maturity, this lager is your handcrafted option when only a refreshing, light beer will do.'),
(82, 340281, 'BED OF NAILS', '6.1', 'Bed of Nails is crafted as an American ode to a traditional English brown. A light hop addition balances the natural sweetness present in the specialty malt. This beer\'s delicate body and dry finish allow flavors of toffee and dark fruit to shine through.'),
(83, 340281, 'HI-PITCH', '6.7', 'A balanced Western North Carolina IPA with bright citrus and tropical fruit aromas. Expect big grapefruit, tangerine and subtle melon flavors from the chorus of Mosaic & Centennial hops to balance out the malt in this dank & drinkable ale.'),
(84, 340281, 'LO-PITCH', '4.9', 'This thirst quenching, easy drinking IPA packs a bright citrus hop punch. Juicy American hops and a light malt bill make Lo-Pitch the perfect pairing for sandy shores, mountain tops, or your bestie\'s birthday party.'),
(85, 476885, 'Gaelic Ale', '5.5', 'A deep amber-colored American ale, featuring a rich malty body. Cascade and Willamette hops add a complex hop flavor and aroma. This ale is exceptionally balanced between malty sweetness and delicate hop bitterness. It has a universal appeal and is our workhorse, accounting for about half of our total production.'),
(86, 476885, 'Oatmeal Porter', '5.9', 'A unique Highland creation, this robust beer is black in color, very malty with hints of chocolate-roasted flavor and a well balanced hop character.\r\nThis style was born on the docks of the Thames of London where dock workers or porters delighted in the strong dark ales brewed by the local pubs with roasted malts. This gave rise to the name by which this style is still known.'),
(87, 476885, 'Saint Terese\'s Pale Ale', '5.1', 'A golden pale having a slightly malty body balanced by an assertive American hop flavor. This pale ale displays a delicate hop nose due to the process of dry hopping. A crisp and refreshing beer perfect for any occasion.\nOur most aromatically hopped beer, St Terese\'s was designed for easy drinking. After the beer is finished fermenting, it is dry hopped which entails adding hops for several days to impart an aromatic hop nose to the beer.'),
(88, 476885, 'Black Mocha Stout', '5.0', 'Highland\'s most robust beer, having a very malty body with a large, roasted chocolate flavor, all achieved solely through the use of special roasted barley grains. It is black in color with a very clean finish and moderate hop flavor. '),
(89, 476885, 'Highland IPA', '7.0', 'A statement from Appalachia. American Chinook, Citra, and Centennial hops from the Pacific Northwest shine in our first West Coast style IPA. A sturdy malt bill frames hints of tropical fruit, lemon rind, grapefruit and dank hops notes. Brilliant and golden in color. expect a dry, resiny, citrusy finish.'),
(90, 511719, 'Magic Hour ', '4.4', 'With a malt base composed of 50% wheat, this is the perfect spring/summer beer and one that is steeped in German tradition. While developed spontaneously in the 16th century, this brew found its prominence in the 1800\'s as it became a favorite in taverns across the Deutschland. Distinctively tart, salty, and refreshing.'),
(91, 511719, '144 (Code Name: Juicy Fruit) ', '7.2', 'Light golden orange in color. Bright and brilliant hop flavor and aroma-grapefruit, orange, a touch of lemon-lime, floral, juicy sweet awesomeness. This beauty of an IPA has just the right amount of that addictive hoppy bitterness that we all love, while the slightest hint of candy-like sweetness from the malt rounds it all out.'),
(92, 511719, 'Luminosity ', '9.0', 'Watch out for this one. Deep golden in color with a wonderful complexity from the classic Trappist yeast strain. Slightly sweet and fruity, with notes of orange, banana, spice, and soft alcohols. This high gravity tripel is surprisingly easy drinking with a light body, and will sneak up on you if you\'re not careful.'),
(93, 511719, 'Leafer', '6.3', 'This incredibly balanced IPA derives it\'s name from the herbaceous perennial we owe all of the glory, the hop leaf. Notes of citrus, fruit, pine, and pepper make this Mosaic dry hopped ale a staff favorite.'),
(94, 511719, 'Uproot ESB ', '5.8', 'Dark amber in color. Complex malt profile reminiscent of bread, toast, and biscuits, we hints of caramel, chocolate, and fruit esters.'),
(95, 567839, 'Aicha', '6.4', 'Japanese for \"love tea,\" Aicha (eye-chah) is a merging of traditions from the Old World and the Orient. Aicha is a barrel-aged American Sour Ale fermented with Green Tea, Toasted Oolong Tea, and Jasmine from our neighbors at Dobra Tea (Asheville, NC). This lovely, local collaboration is more than the sum of its worldwide parts.'),
(96, 567839, 'Amorous', '7.0', 'Amorous is aged in red wine barrels for approximately 8-10 months, and then dry hopped with over 3.5 pounds per barrel of Mosaic, Amarillo, Citra, and Centennial. We love this beer both fresh off the dry hop and cellar aged.'),
(97, 567839, 'Angel of Darkness', '11.0', 'Angel of Darkness is a barrel-aged American sour. This ale is blended with 1.5 pounds per gallon of boysenberries, blackberries, raspberries, and cherries and aged in Oloroso sherry casks. After 14 months of aging in these flavor-intense barrels, the beer is blended onto another 1.5 pound per gallon of these dark fruits in stainless steel tanks for 2 months. A total of 3 tons of fruit and 16 months of maturation later, we give you Angel of Darkness.'),
(98, 567839, 'Black Angel', '7.0', 'Black Angel is aged in bourbon barrels on over 1.5 pounds per gallon of tart Michigan Montmorency cherries. It rests in the barrels for approximately 9 months and is then artfully blended to achieve complexity.'),
(99, 567839, 'Brettaberry', '5.5', 'Brettaberry, a tart farmhouse ale, is inspired by freshly baked berry pie. Featuring a half-pound per gallon of strawberries, blueberries, and blackberries, the acidity of the berries with the rustic funk of our house culture are rounded by the flaky crust finish of Haw Creek Honey, Riverbend Pilsner and wheat malts. From our summer memories to yours, cheers.'),
(100, 100002, 'Carolina Sparkle Party (Berliner Weisse)', '4.0', 'We use a traditional Kettle Sour brewing method and a hint of Brettanomyces to add depth and tartness to this light, German Wheat Beer. A party in your mouth!!!'),
(101, 100002, 'Slow Boat to India (Session IPA)', '4.0', 'A plethora of exciting American hops contribute bold flavors of pineapple and stonefruit along with a pleasant bitterness. Light in body, high in drinkability...'),
(102, 100002, 'Project Pils (Carolina Pilsner)', '4.8', 'Brewed exclusively with locally grown Pilsner malt produced by our friends in Asheville, NC at Riverbend Malt. Sterling hops add herbal characteristics and moderate bitterness that complement the grainy sweetness and a crisp, dry finish. To be consumed with friends in mass quantities.'),
(103, 100002, 'Dos Amigos (Vienna Lager)', '5.0', 'Unfiltered and Unafraid like \"Two Friends\" should be... this rustic lager was brewed with a traditional decoction-style mash to add a light, toasted malt aroma and flavor with just the right amount of hop bitterness to provide a balanced finish.'),
(104, 100002, 'Freedom Park Pale (American Pale Ale)', '5.2', 'Citrusy, floral notes from Cascade hops pair perfectly with a malty, caramel backbone and medium carbonation. Balance is key.');

-- --------------------------------------------------------

--
-- Table structure for table `breweries`
--

CREATE TABLE `breweries` (
  `brewery_ID` int(11) NOT NULL,
  `brewery_Name` varchar(50) NOT NULL,
  `owner` varchar(50) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `pword` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `breweries`
--

INSERT INTO `breweries` (`brewery_ID`, `brewery_Name`, `owner`, `uname`, `pword`, `address`, `city`, `state`, `phone`) VALUES
(100234, 'Birdsong Brewing Company', '', '', '', '', '', '', ''),
(254896, 'Blue Blaze Brewing', '', '', '', '', '', '', ''),
(100000, 'Free Range Brewing', '', '', '', '', '', '', ''),
(100001, 'Heist Brewery', '', '', '', '', '', '', ''),
(100002, 'Legion Brewing', '', '', '', '', '', '', ''),
(784044, 'Heist Brewery', '', '', '', '', '', '', ''),
(351960, 'NoDa Brewing Company', '', '', '', '', '', '', ''),
(548421, 'Sugar Creek Brewing Company', '', '', '', '215 Southside Dr', 'Charlotte', 'North Carolina', '(704) 521-3333'),
(357951, 'Wooden Robot Brewery', '', '', '', '1440 S Tryon St #110', 'Charlotte', 'North Carolina', '(980) 819-7875'),
(654987, 'Cabarrus Brewing Company', '', '', '', '329 McGill Ave NW', 'Concord', 'North Carolina', '(704) 490-4487'),
(987654, 'High Branch Brewing Co.', '', '', '', '325 McGill Ave NW #148', 'Concord', 'North Carolina', '(704) 706-3807'),
(159753, 'Red Hill Brewing Company', '', '', '', '20 Church St S', 'Concord', 'North Carolina', '(704) 784-2337'),
(357412, 'Twenty-Six Acres Brewing Company', '', '', '', '7285 W Winds Blvd NW', 'Concord', 'North Carolina', '(980) 277-2337'),
(484707, 'Ass Clown Brewing Company', '', '', '', '10620 Bailey Rd E', 'Cornelius', 'North Carolina', '(980) 505-0399'),
(572224, 'Bayne Brewing Company', '', '', '', '19507 W Catawba Ave i', 'Cornelius', 'North Carolina', '(704) 897-6426'),
(750667, 'D9 Brewing Company', '', '', '', '11138 Treynorth Dr', 'Cornelius', 'North Carolina', '(704) 457-9368'),
(890566, 'Primal Brewery', '', '', '', '16432 Old Statesville Rd', 'Huntersville', 'North Carolina', '(704) 947-2920'),
(983883, 'Asheville Brewing Company', '', '', '', '77 Coxe Ave', 'Asheville', 'North Carolina', '(828) 255-4077'),
(900628, 'Green Man Brewery', '', '', '', '27 Buxton Ave', 'Asheville', 'North Carolina', '(828) 252-5502'),
(340281, 'Hi-Wire Brewing', '', '', '', '197 Hilliard Ave', 'Asheville', 'North Carolina', '(828) 738-2448'),
(476885, 'Highland Brewing Company', '', '', '', '12 Old Charlotte Hwy', 'Asheville', 'North Carolina', '(828) 299-3370'),
(511719, 'Twin Leaf Brewery', '', '', '', '144 Coxe Ave', 'Asheville', 'North Carolina', '(828) 774-5000'),
(567839, 'Wicked Weed Brewing Pub', '', '', '', '91 Biltmore Ave', 'Asheville', 'North Carolina', '(828) 575-9599');

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `beer_ID` int(11) NOT NULL,
  `rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ratings`
--

INSERT INTO `ratings` (`beer_ID`, `rating`) VALUES
(1, 4),
(1, 4),
(1, 4),
(1, 1),
(1, 4),
(2, 4),
(3, 3),
(4, 5),
(1, 5),
(1, 5),
(7, 4),
(51, 5),
(3, 1),
(95, 5),
(71, 2),
(0, 0),
(0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `user_ID` int(11) NOT NULL,
  `beer_ID` int(11) NOT NULL,
  `brewery` varchar(75) NOT NULL,
  `name` varchar(75) NOT NULL,
  `where_tried` varchar(100) NOT NULL,
  `when_tried` date NOT NULL,
  `rate` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`user_ID`, `beer_ID`, `brewery`, `name`, `where_tried`, `when_tried`, `rate`, `description`) VALUES
(12, 1, 'Birdsong Brewing Company', 'Jalapeno Pale Ale', 'Tin Kitchen', '2017-04-21', '&#9733;&#9733;&#9733;&#9733;', 'This is a pretty solid beer. The Jalapeno taste is not spicy, but it is very prominent in the flavor of this beer. Light and refreshing.'),
(12, 1, 'Birdsong Brewing Company', 'Jalapeno Pale Ale', 'CBC', '2017-04-21', '&#9733;', 'Yikes! Jalapeno in beer. I thought I would give this one a try, but I was not fond at all.'),
(3, 4, 'Birdsong Brewing Company', 'Higher Ground IPA', 'CBC', '2017-04-11', '&#9733;&#9733;&#9733;&#9733;&#9733;', 'Wow! I am extremely impressed with this beer. You can tell Birdsong really took their time with this one and produced a great IPA that anyone can enjoy.'),
(13, 1, 'Birdsong Brewing Company', 'Jalapeno Pale Ale', 'Somewhere in cherlotte', '2017-04-24', '&#9733;&#9733;&#9733;&#9733;&#9733;', 'This Beer is Awesome!'),
(15, 1, 'Birdsong Brewing Company', 'Jalapeno Pale Ale', 'A place', '2017-04-24', '&#9733;&#9733;&#9733;&#9733;&#9733;', 'Amazing!'),
(3, 7, 'Blue Blaze Brewing', 'Double Blaze Black IPA', 'BWW', '2017-04-20', '&#9733;&#9733;&#9733;&#9733;', 'Great beer. Good taste.'),
(3, 51, 'Red Hill Brewing Company', 'Underground Pale Ale', 'here', '2017-04-06', '&#9733;&#9733;&#9733;&#9733;&#9733;', 'vwrVAE'),
(3, 3, 'Birdsong Brewing Company', 'Free Will Pale Ale', 'F', '2017-04-18', '&#9733;', 'REFER'),
(16, 95, 'Wicked Weed Brewing Pub', 'Aicha', 'lol', '2017-04-27', '&#9733;&#9733;&#9733;&#9733;&#9733;', 'lll'),
(16, 71, 'Asheville Brewing Company', 'Amstel Light', '90', '2017-04-27', '&#9733;&#9733;', 'lllll'),
(16, 0, '', '', '', '0000-00-00', '', ''),
(16, 0, '', '', '', '0000-00-00', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `pword` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `pic` varchar(100) NOT NULL,
  `brew_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `uname`, `pword`, `type`, `fname`, `lname`, `pic`, `brew_ID`) VALUES
(3, 'test', 'test', 'user', 'Chris', 'Lau', '306115_3561259429686_658679744_n.jpg', 0),
(8, 'chrisalau32', 'kathryn33', 'user', 'Christopher ', 'Lau', 'cmon.jpg', 0),
(9, 'brew', 'brew', 'brewery', 'test', 'test', '', 100234),
(10, 'crizzle', 'test', 'user', 'testing', 'testing', '15391040_1014927555301624_5804146188154643802_n.jpg', 0),
(11, 'asdf', 'asdf@1234faF', 'user', 'Sagan', 'Cichocki', '', 0),
(12, 'beerdrinker32', 'password', 'user', 'Beer', 'Drinker', 'beer-cocktail-recipes.jpg', 0),
(15, 'something', 'something123', 'user', 'Sagan ', 'Cichocki', 'IMG_20160528_114933.jpg', 0),
(16, 'gmo', 'mohamud123', 'user', 'g', 'mo', '', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `beers`
--
ALTER TABLE `beers`
  ADD PRIMARY KEY (`beer_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `beers`
--
ALTER TABLE `beers`
  MODIFY `beer_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
